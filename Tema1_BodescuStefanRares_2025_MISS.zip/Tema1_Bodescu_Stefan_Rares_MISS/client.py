import socket
import time
import argparse


# TCP Client
def send_tcp_data(host="127.0.0.1", port=5000, buffer_size=65535):
    buffer = bytearray(5242880000)  
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((host, port))

    message_size = len(buffer)
    client.send(message_size.to_bytes(8, byteorder='big'))
    client.send(buffer_size.to_bytes(8, byteorder='big'))

    sent_bytes = 0
    sent_messages = 0
    start_time = time.time()

    for i in range(0, len(buffer), buffer_size):
        client.send(buffer[i:i + buffer_size])
        sent_bytes += buffer_size
        sent_messages += 1

    client.send(b"END")
    end_time = time.time()
    client.close()

    total_time = end_time - start_time
    print(f"Sent {sent_bytes / (1024**3):.2f} GB in {total_time:.2f} seconds")
    print(f"[TCP] Sent: {sent_bytes} bytes, Messages Sent: {sent_messages}, Time: {end_time - start_time:.2f} sec")
    print(f"Transfer speed: {sent_bytes / (1024**2) / total_time:.2f} MB/s")


# UDP Client
def send_udp_data(host="127.0.0.1", port=5000, buffer_size=65507, stop_and_wait=False):
    buffer = bytearray(1_073_741_824)  
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client.settimeout(1)

    sent_bytes = 0
    sent_messages = 0
    retransmissions = 0
    start_time = time.time()

    for i in range(0, len(buffer), min(buffer_size, 65507 - 4)):
        packet_id = sent_messages.to_bytes(4, 'big')  
        packet_data = packet_id + buffer[i:i + min(buffer_size, 65507 - 4)]

        while True:
            client.sendto(packet_data, (host, port))
            sent_bytes += len(packet_data) - 4
            sent_messages += 1

            if stop_and_wait:
                try:
                    ack, _ = client.recvfrom(4)
                    ack_id = int.from_bytes(ack, 'big')
                    if ack_id == sent_messages - 1:
                        break  
                except socket.timeout:
                    retransmissions += 1  
                break

    client.sendto(b"END", (host, port))  
    end_time = time.time()
    client.close()

    total_time = end_time - start_time
    print(f"Sent {sent_bytes / (1024**3):.2f} GB in {total_time:.2f} seconds")
    print(f"[UDP] Sent: {sent_bytes} bytes, Messages Sent: {sent_messages}, Retransmissions: {retransmissions}, Time: {end_time - start_time:.2f} sec")
    print(f"Transfer speed: {sent_bytes / (1024**2) / total_time:.2f} MB/s")

def main():
    parser = argparse.ArgumentParser(description="Select protocol and mode")
    parser.add_argument('--protocol', choices=['tcp', 'udp'], required=True, help='Protocol to use')
    parser.add_argument('--mode', choices=['streaming', 'stop_and_wait'], required=True, help='Transmission mode')
    parser.add_argument('--host', type=str, default='127.0.0.1', help='Server host (default: 127.0.0.1)')
    parser.add_argument('--port', type=int, default=5000, help='Server port (default: 5000)')
    parser.add_argument('--buffer_size', type=int, default=65507, help='Buffer size (default: 65507 bytes)')

    args = parser.parse_args()

    if args.protocol == 'tcp':
        send_tcp_data(host=args.host, port=args.port, buffer_size=args.buffer_size)
    elif args.protocol == 'udp':
        send_udp_data(host=args.host, port=args.port, buffer_size=args.buffer_size, stop_and_wait=(args.mode == 'stop_and_wait'))


if __name__ == "__main__":
    main()
