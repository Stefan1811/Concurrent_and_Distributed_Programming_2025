import socket
import argparse
import time

# TCP server
def tcp_server(host="0.0.0.0", port=5000):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((host, port))
    server.listen(1)
    print(f"TCP Server listening on {host}:{port}")

    connection, client_address = server.accept()
    print(f"Connected by {client_address}")

    message_size = int.from_bytes(connection.recv(8), byteorder='big')
    message_buffer = int.from_bytes(connection.recv(8), byteorder='big')

    print(f"Message size: {message_size}   Buffer size: {message_buffer}")

    message = b''
    total_bytes= 0
    total_messages= 0
    connection.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1000000000)
    start_time = time.time()

    while True:
        data = connection.recv(message_buffer)
        if not data:
            break
        message += data
        total_bytes += len(data)
        total_messages += 1

        if total_bytes >= message_size:
            break
    end_time = time.time()
    connection.close()
    server.close()

    total_time = end_time - start_time
    print(f"[TCP] Session Summary: Messages Received: {total_messages}, Bytes Received: {total_bytes}, Time: {end_time - start_time:.2f} sec")
    print(f"Received {total_bytes / (1024**3):.2f} GB in {total_time:.2f} seconds")
    print(f"Transfer speed: {total_bytes / (1024**2) / total_time:.2f} MB/s")

# UDP server
def udp_server(host="0.0.0.0", port=5000, buffer_size=65507):
    server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server.bind((host, port))
    print(f"[UDP] Server listening on {host}:{port}")

    while True:
        total_bytes = 0
        total_messages = 0
        received_packets = set()
        start_time = time.time()
        while True:
            data, addr = server.recvfrom(65507)
            if data == b"END":
                break
            packet_id = int.from_bytes(data[:4], 'big')
            received_packets.add(packet_id)
            total_bytes += len(data)-4
            total_messages += 1
            server.sendto(packet_id.to_bytes(4, 'big'), addr)

        end_time = time.time()
        total_time = end_time - start_time
        expected_packets = max(received_packets) + 1 if received_packets else 0
        lost_packets = expected_packets - len(received_packets)
        loss_rate = (lost_packets / expected_packets) * 100 if expected_packets > 0 else 0

        print(f"[UDP] Session Summary: Messages Received: {total_messages}, Bytes Received: {total_bytes}, Time: {end_time - start_time:.2f} sec, Loss Rate: {loss_rate:.2f}%")
        print(f"Received {total_bytes / (1024**3):.2f} GB in {total_time:.2f} seconds")
        print(f"Transfer speed: {total_bytes / (1024**2) / total_time:.2f} MB/s")



def run_servers(protocol):
    if protocol == "tcp":
        tcp_server()
    elif protocol == "udp":
        udp_server()
    else:
        print(f"Unknown protocol: {protocol}. Please choose 'tcp', 'udp'.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Start a server with the specified protocol.")
    parser.add_argument(
        "--protocol", 
        choices=["tcp", "udp"], 
        required=True, 
        help="Select the protocol to use (tcp, udp)"
    )
    args = parser.parse_args()
    
    run_servers(args.protocol)
